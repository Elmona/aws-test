#!/bin/bash

mkdir build
rm ./build/lambda.zip
zip -r ./build/lambda.zip *


