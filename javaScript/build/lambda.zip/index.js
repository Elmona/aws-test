'use strict'

/**
 * handler
 * Empty function
 *
 * @param event
 * @param context
 * @param callback
 */
const handler = (event, context, callback) => {
  callback(null, event)
}

module.exports = {
  handler,
}
